"""Frozen learned visual features with causal, integrated spatial association.
Probabilities below are explicit model weights, NOT calibrated confidence.
"""
from pathlib import Path
import cv2, numpy as np, torch

class Encoder:
 def __init__(self, repo, device='mps'):
  self.device=device;self.model=torch.hub.load(str(repo),'dinov2_vitb14',source='local',pretrained=True).eval().to(device)
  self.mean=torch.tensor([.485,.456,.406],device=device)[None,:,None,None];self.std=torch.tensor([.229,.224,.225],device=device)[None,:,None,None]
 @torch.inference_mode()
 def __call__(self,frame):
  rgb=cv2.resize(frame,(322,238))[:,:,::-1].copy();x=torch.from_numpy(rgb).to(self.device).float().permute(2,0,1)[None]/255
  f=self.model.forward_features((x-self.mean)/self.std)['x_norm_patchtokens'][0]
  return torch.nn.functional.normalize(f,dim=-1).cpu().numpy().reshape(17,23,-1)

def unit(v): return v/max(np.linalg.norm(v),1e-12)

def candidate_bank(features,anchor):
 s=features@anchor;copy=s.copy();xy=[];values=[];emb=[]
 for _ in range(12):
  y,x=np.unravel_index(copy.argmax(),copy.shape);xy.append([(x+.5)*14,(y+.5)*14]);values.append(s[y,x]);emb.append(features[y,x]);copy[max(0,y-2):y+3,max(0,x-2):x+3]=-np.inf
 return np.array(xy),np.array(values),np.array(emb)

class Belief:
 def __init__(self,anchor,position,mode,fps):
  self.anchor=anchor.copy();self.adaptive=anchor.copy();self.last=np.array(position,dtype=float);self.context=self.last.copy();self.velocity=np.zeros(2);self.age=0.;self.mode=mode;self.fps=fps;self.weights=np.ones(3)/3;self.history=[];self.updates=0
 def step(self,xy,similarity,embeddings,flow):
  self.age+=1/self.fps
  cx,cy=np.rint(self.context).astype(int);cx=np.clip(cx,5,316);cy=np.clip(cy,5,232)
  delta=np.median(flow[cy-5:cy+6,cx-5:cx+6].reshape(-1,2),axis=0)
  self.context=np.clip(self.context+delta,[0,0],[321,237]);means=np.stack([self.last,self.last+self.velocity*min(self.age,2),self.context]);variance=144+400*self.age
  d2=((xy[:,None,:]-means[None,:,:])**2).sum(-1);density=np.exp(-d2/(2*variance))/(2*np.pi*variance)
  prior=density[:,1] if self.mode=='motion' else density@self.weights
  appearance=similarity.copy()
  if self.mode=='mixture_adapt':appearance=.8*similarity+.2*(embeddings@self.adaptive)
  score=12*appearance
  if self.mode!='appearance':score+=.25*np.log(np.maximum(prior*322*238,1e-8))
  order=np.argsort(-score);j=int(order[0]);gap=float(score[j]-score[order[1]]);accepted=bool(similarity[j]>=.65 and gap>=.15)
  before=self.last.copy();old_age=self.age;state='ambiguous'
  if accepted:
   state='reacquired' if self.age>2/self.fps else 'observed'
   self.velocity=.5*self.velocity+.5*(xy[j]-self.last)/max(self.age,1/self.fps)
   posterior=self.weights*np.maximum(density[j],1e-12);self.weights=.95*posterior/posterior.sum()+.05/3
   self.last=xy[j].copy();self.context=self.last.copy();self.age=0.;self.history.append(self.last.tolist())
   if self.mode=='mixture_adapt' and similarity[j]>=.8 and gap>=.5:self.adaptive=unit(.95*self.adaptive+.05*embeddings[j]);self.updates+=1
  elif self.age>5:state='lost'
  return dict(candidate=xy[j].tolist(),accepted=accepted,state=state,initial_anchor_cosine=float(similarity[j]),association_score=float(score[j]),association_gap=gap,last_supported=self.last.tolist(),previous_supported=before.tolist(),evidence_age_s=self.age,hypotheses=means.tolist(),hypothesis_weights=self.weights.tolist(),variance_px2=variance,uncertainty_calibrated=False,selected_index=j,appearance_index=int(similarity.argmax()),memory_updates=self.updates)
