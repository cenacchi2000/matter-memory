import unittest,numpy as np
from model import Belief
from speech import describe
class TestBelief(unittest.TestCase):
 def test_memory_changes_selection(self):
  a=np.array([1.,0.]);xy=np.array([[220.,180.],[45.,45.]]);s=np.array([.90,.87]);e=np.stack([a,a]);flow=np.zeros((238,322,2))
  appearance=Belief(a,[45,45],'appearance',30).step(xy,s,e,flow)
  memory=Belief(a,[45,45],'mixture',30).step(xy,s,e,flow)
  self.assertEqual(appearance['selected_index'],0);self.assertEqual(memory['selected_index'],1)
 def test_rejection_preserves_evidence(self):
  b=Belief(np.array([1.,0.]),[45,45],'mixture',30);r=b.step(np.array([[200.,200.],[220.,210.]]),np.array([.1,.2]),np.eye(2),np.zeros((238,322,2)))
  self.assertFalse(r['accepted']);np.testing.assert_array_equal(b.last,[45,45]);self.assertGreater(r['evidence_age_s'],0);self.assertAlmostEqual(sum(r['hypothesis_weights']),1)
 def test_anchor_immutable(self):
  a=np.array([1.,0.]);b=Belief(a,[45,45],'mixture_adapt',30)
  for _ in range(4):b.step(np.array([[45.,45.],[250.,200.]]),np.array([.9,.1]),np.array([[.98,.2],[0,1]]),np.zeros((238,322,2)))
  np.testing.assert_array_equal(b.anchor,a);self.assertGreater(b.updates,0)
 def test_prefix(self):
  def run(n):
   b=Belief(np.array([1.,0.]),[45,45],'mixture',30)
   return [b.step(np.array([[45.+k,45.],[250.,200.]]),np.array([.9,.1]),np.eye(2),np.zeros((238,322,2))) for k in range(n)]
  self.assertEqual(run(4),run(8)[:4])
 def test_no_hidden_property_fabrication(self):
  t=describe({'state':{'last_supported':[12,15],'evidence_age_s':3,'accepted':False}})
  self.assertIn('cannot currently verify',t);self.assertIn('cannot infer',t)
if __name__=='__main__':unittest.main()
