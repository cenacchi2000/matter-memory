"""Grounded response generator. The caller supplies its documented speech function.
No Tritium API is invented here; no physical actuator call is made.
"""
import argparse,json
from pathlib import Path

def describe(evidence):
    p=evidence.get('properties',{});state=evidence['state'];items=[]
    if p.get('color_description'):items.append('In the initial visible observation, the selected region was '+p['color_description']+'.')
    if p.get('mask_width_px') is not None:items.append(f"Its visible silhouette spanned {p['mask_width_px']} pixels horizontally and {p['mask_height_px']} vertically in the stored image. These are image measurements, not physical dimensions.")
    x,y=state['last_supported'];age=state['evidence_age_s']
    items.append(f'My last supported image position is x {x:.0f}, y {y:.0f}, from {age:.1f} seconds ago.')
    if state['accepted']:items.append('The current appearance and association gates accept a candidate, but their scores are not calibrated identity probabilities.')
    else:items.append('I cannot currently verify the original object. Its remembered location is not a measurement of where it is now.')
    items.append('Stationary, independently moving, and local-context motion remain model alternatives. I have not established that it is inside a container.')
    items.append('I cannot infer its hidden surface, mass, material, or exact hidden position from this evidence.')
    return ' '.join(items)

async def respond(evidence, speak):
    """Inject an authorized, documented simulator speech callable after integration."""
    text=describe(evidence)
    await speak(text)
    return text

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('evidence');a=p.parse_args();print(describe(json.loads(Path(a.evidence).read_text())))
