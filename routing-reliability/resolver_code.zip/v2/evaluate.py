from pathlib import Path
import argparse,json,hashlib,time,cv2,numpy as np
from model import Encoder,Belief,unit,candidate_bank
p=argparse.ArgumentParser();p.add_argument('--data',nargs='+',required=True);p.add_argument('--repo',required=True);p.add_argument('--output',required=True);p.add_argument('--device',default='mps');a=p.parse_args();out=Path(a.output);out.mkdir(exist_ok=True,parents=True)
start=time.time();encoder=Encoder(a.repo,a.device);rows=[];changes={};manifest=[]
for directory in a.data:
 root=Path(directory)
 for video in sorted(root.rglob('*.mp4')):
  queries=sorted(video.parent.glob(video.stem+'_*_query.png'),key=lambda p:int(p.stem.split('_')[-2]));targets=sorted(video.parent.glob(video.stem+'_*_snitch.png'),key=lambda p:int(p.stem.split('_')[-2]))
  if not queries:continue
  q=int(queries[0].stem.split('_')[-2]);targets=[t for t in targets if int(t.stem.split('_')[-2])>q]
  if not targets:continue
  cap=cv2.VideoCapture(str(video));fps=cap.get(cv2.CAP_PROP_FPS);cap.set(cv2.CAP_PROP_POS_FRAMES,q);ok,frame=cap.read()
  if not ok:continue
  frame=cv2.resize(frame,(322,238));mask=cv2.resize(cv2.imread(str(queries[0]),0),(322,238),interpolation=cv2.INTER_NEAREST);y,x=np.where(mask>127)
  if not len(x):continue
  features=encoder(frame);small=cv2.resize(mask,(23,17),interpolation=cv2.INTER_AREA)>32
  if not small.any():small[min(16,int(y.mean()/14)),min(22,int(x.mean()/14))]=True
  anchor=unit(features[small].mean(0));pos=[float(x.mean()),float(y.mean())];models={m:Belief(anchor,pos,m,fps) for m in ['appearance','motion','mixture','mixture_adapt']};trace=[];stored={};previous=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
  for idx in range(q+1,max(int(t.stem.split('_')[-2]) for t in targets)+1):
   ok,frame=cap.read()
   if not ok:break
   frame=cv2.resize(frame,(322,238));gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY);flow=cv2.calcOpticalFlowFarneback(previous,gray,None,.5,2,15,2,5,1.1,0);previous=gray
   f=encoder(frame);xy,sim,emb=candidate_bank(f,anchor);states={m:b.step(xy,sim,emb,flow) for m,b in models.items()};stored[idx]=states;trace.append(dict(frame=idx,methods=states,candidates=xy.tolist()))
  cap.release()
  for t in targets:
   idx=int(t.stem.split('_')[-2]);states=stored.get(idx)
   if not states:continue
   # Endpoint labels are read only after completing predictions for this clip.
   mask=cv2.imread(str(t),0);H,W=mask.shape
   for method,s in states.items():
    x,y=np.rint(np.array(s['candidate'])*[W/322,H/238]).astype(int);hit=bool(0<=x<W and 0<=y<H and mask[y,x]>127)
    rows.append(dict(dataset=root.name,clip=video.stem,frame=idx,method=method,inside_target=hit,accepted=s['accepted'],accepted_hit=hit and s['accepted'],accepted_miss=not hit and s['accepted'],**{k:s[k] for k in ['candidate','association_gap','initial_anchor_cosine','evidence_age_s']}))
  name=root.name+'__'+video.stem;(out/(name+'.json')).write_text(json.dumps(trace));manifest.append(dict(dataset=root.name,clip=video.stem,video_sha256=hashlib.sha256(video.read_bytes()).hexdigest(),query_frame=q,frames_processed=len(trace)))
  changes[name]={m:sum(t['methods'][m]['selected_index']!=t['methods']['appearance']['selected_index'] for t in trace) for m in models};(out/'endpoints.json').write_text(json.dumps(rows,indent=2));(out/'manifest.json').write_text(json.dumps(manifest,indent=2));print(name,'frames',len(trace),'endpoints',len(targets),flush=True)
summary={}
for dataset in sorted(set(r['dataset'] for r in rows)):
 summary[dataset]={m:{'endpoints':len(rr:=[r for r in rows if r['dataset']==dataset and r['method']==m]),'candidate_hits':sum(r['inside_target'] for r in rr),'accepted_hits':sum(r['accepted_hit'] for r in rr),'accepted_misses':sum(r['accepted_miss'] for r in rr),'abstentions':sum(not r['accepted'] for r in rr)} for m in models}
summary['runtime_seconds']=time.time()-start;(out/'summary.json').write_text(json.dumps(summary,indent=2));(out/'selection_changes.json').write_text(json.dumps(changes,indent=2));print(json.dumps(summary,indent=2))
