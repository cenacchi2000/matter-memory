# Object Memory under Natural Occlusion

Authoritative revision: v2 learned appearance and spatial association. The main manuscript is 8 pages TOTAL, including references; it is not eight pages excluding references. The supplement is 20 pages and documents all 36 clips. The manuscript has 47 primary-source-verified references.

## Completed experiments

36 clips, 56 sparse target-mask endpoints, 7,530 processed frames. Office: appearance 11 accepted hits/1 miss; spatial mixture 11 hits/3 misses. Cup Games: appearance 6 hits/11 misses; mixture 6 hits/12 misses. The memory variants do not establish improvement. These are development collections, not untouched tests; continuous identity metrics remain unmeasured.

## Official Ameca project

Created in the authenticated account: Occlusion Memory — Evidence Replay, using the official Ameca Gen 1 Animator template. Native blinking and breathing tracks were saved. Voice creation reports no available voices; ad-0005 is disconnected and the Scripts runtime is unavailable. No response script has been installed or run in Tritium. The local v2/speech.py is a grounded text generator with an injectable speech callable, not an undocumented robot API.

## Reproduction

The complete ZIP includes both local TCOW collections and a copy of the DINOv2 source used. It does not bundle model weights. The hub loader obtains the official ViT-B/14 checkpoint if it is absent from the torch cache. Its expected hash is in v2/provenance.json. Retain TCOW and DINOv2 upstream licenses and data terms.

```
python -m pip install -r requirements.txt
python v2/test_model.py
python code/test_resolver.py
python v2/evaluate.py --data data/rubric_office data/rubric_cup_games --repo vendor/dinov2 --output v2/results --device mps
python -m http.server 8792 --directory site
```

Use --device cpu on systems without MPS. Reproduction requires the dependencies used by DINOv2 hub inference as well as the pinned versions here. Dense feature extraction is frozen; no training is claimed.

## Contents

- main.tex / main.pdf: revised study with actual positive and negative findings.
- supplement.tex / supplement.pdf: complete 20-page case audit.
- v2/: method, evaluator, tests, protocol, hashes, reference metadata, figures and all inference traces.
- code/ and results/: unchanged original classical prototype and its recorded results.
- research/: preceding proposal audit and research plan, retained as history.
- archive/v1/: prior manuscript and supplement.
- REVIEW_RESPONSE.csv: explicit status of the mock panel's major requirements.

The released method does not infer semantic containment, calibrated hidden position, material/mass, or real robot transfer. SAMURAI/DAM4SAM/Cutie and other full tracker comparisons remain outstanding. Descriptive threshold curves are not held-out calibration. The static site labels archived CoTracker demos separately because their temporal access and initialization differ.
